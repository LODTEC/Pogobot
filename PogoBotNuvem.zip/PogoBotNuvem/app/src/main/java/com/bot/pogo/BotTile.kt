package com.bot.pogo

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast

class BotTile : TileService() {
    override fun onStartListening() { refresh() }

    override fun onClick() {
        val s = BotService.instance
        if (s == null) {
            Toast.makeText(this, "Ative o LOD SHINYS na Acessibilidade", Toast.LENGTH_SHORT).show()
        } else {
            s.toggle()
        }
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.state = if (BotStore.running.value) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        t.label = if (BotStore.running.value) "Bot rodando" else "Bot parado"
        t.updateTile()
    }
}
