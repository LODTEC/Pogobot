package com.bot.pogo

import android.graphics.Bitmap
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.SystemClock

/** Guarda o último quadro da tela (convertido em Bitmap) vindo do MediaProjection. */
object ScreenGrabber {
    @Volatile private var last: Bitmap? = null
    @Volatile private var lastConv = 0L
    private var width = 0
    private var height = 0

    fun attach(reader: ImageReader, w: Int, h: Int, handler: Handler) {
        width = w
        height = h
        last = null
        lastConv = 0L
        reader.setOnImageAvailableListener({ rd ->
            val img = try { rd.acquireLatestImage() } catch (e: Exception) { null }
            if (img != null) {
                try {
                    val now = SystemClock.elapsedRealtime()
                    if (now - lastConv >= 600) {
                        convert(img)
                        lastConv = now
                    }
                } finally {
                    img.close()
                }
            }
        }, handler)
    }

    private fun convert(img: Image) {
        val plane = img.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(plane.buffer)
        last = if (rowPadding == 0) bmp else Bitmap.createBitmap(bmp, 0, 0, width, height)
    }

    fun grab(): Bitmap? = last

    fun detach() { last = null }
}
