package com.bot.pogo

import android.content.Context
import android.content.SharedPreferences
import android.graphics.PointF
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Estado compartilhado entre o app (Compose) e o serviço de acessibilidade. */
object BotStore {
    private var prefs: SharedPreferences? = null

    val running = MutableStateFlow(false)
    val serviceOn = MutableStateFlow(false)
    val status = MutableStateFlow("Parado")
    val nextCheckAt = MutableStateFlow(0L)
    val cycles = MutableStateFlow(0)
    val captures = MutableStateFlow(0)
    val speedFixes = MutableStateFlow(0)
    val logs = MutableStateFlow<List<String>>(emptyList())

    private val defaultPoints = mapOf(
        "left" to floatArrayOf(0.776f, 0.359f),
        "right" to floatArrayOf(0.920f, 0.360f),
        "player" to floatArrayOf(0.500f, 0.620f),
        "speed" to floatArrayOf(0.400f, 0.656f),
        "weather" to floatArrayOf(0.450f, 0.677f)
    )

    fun init(c: Context) {
        if (prefs != null) return
        prefs = c.applicationContext.getSharedPreferences("pogobot", Context.MODE_PRIVATE)
        cycles.value = getInt("c_cycles", 0)
        captures.value = getInt("c_captures", 0)
        speedFixes.value = getInt("c_speed", 0)
    }

    // ---------- configurações ----------
    fun getInt(key: String, def: Int): Int = prefs?.getInt(key, def) ?: def
    fun putInt(key: String, v: Int) { prefs?.edit()?.putInt(key, v)?.apply() }
    fun getBool(key: String, def: Boolean): Boolean = prefs?.getBoolean(key, def) ?: def
    fun putBool(key: String, v: Boolean) { prefs?.edit()?.putBoolean(key, v)?.apply() }

    fun point(key: String): PointF {
        val d = defaultPoints[key] ?: floatArrayOf(0.5f, 0.5f)
        return PointF(
            prefs?.getFloat("${key}_x", d[0]) ?: d[0],
            prefs?.getFloat("${key}_y", d[1]) ?: d[1]
        )
    }

    fun setPoint(key: String, x: Float, y: Float) {
        prefs?.edit()?.putFloat("${key}_x", x)?.putFloat("${key}_y", y)?.apply()
    }

    fun resetPoints() {
        val e = prefs?.edit() ?: return
        for (k in defaultPoints.keys) { e.remove("${k}_x"); e.remove("${k}_y") }
        e.apply()
    }

    // ---------- status / log ----------
    fun setStatus(s: String) { status.value = s }

    fun log(msg: String) {
        val t = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        logs.update { (listOf("$t  $msg") + it).take(200) }
    }

    fun clearLog() { logs.value = emptyList() }

    // ---------- contadores ----------
    fun addCycle() { cycles.update { it + 1 }; putInt("c_cycles", cycles.value) }
    fun addCapture() { captures.update { it + 1 }; putInt("c_captures", captures.value) }
    fun addSpeedFix() { speedFixes.update { it + 1 }; putInt("c_speed", speedFixes.value) }

    fun resetCounters() {
        cycles.value = 0; captures.value = 0; speedFixes.value = 0
        putInt("c_cycles", 0); putInt("c_captures", 0); putInt("c_speed", 0)
    }
}
