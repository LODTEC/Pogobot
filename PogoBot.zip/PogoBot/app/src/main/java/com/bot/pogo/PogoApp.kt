package com.bot.pogo

import android.app.Application

class PogoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        BotStore.init(this)
    }
}
