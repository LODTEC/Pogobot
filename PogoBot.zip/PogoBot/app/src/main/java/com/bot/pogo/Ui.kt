package com.bot.pogo

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Green = Color(0xFF22C55E)
private val Red = Color(0xFFEF4444)

@Composable
fun PogoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Green,
            onPrimary = Color(0xFF052E16),
            background = Color(0xFF0B1220),
            surface = Color(0xFF111B2E),
            surfaceVariant = Color(0xFF1B2740),
            onBackground = Color(0xFFE2E8F0),
            onSurface = Color(0xFFE2E8F0),
            onSurfaceVariant = Color(0xFFCBD5E1),
            error = Red
        ),
        content = content
    )
}

@Composable
fun AppRoot() {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                listOf("🏠" to "Início", "⚙️" to "Ajustes", "📜" to "Log")
                    .forEachIndexed { i, (emoji, label) ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(emoji) },
                            label = { Text(label) }
                        )
                    }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen()
                1 -> SettingsScreen()
                else -> LogScreen()
            }
        }
    }
}

// ============================ INÍCIO ============================
@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val running by BotStore.running.collectAsState()
    val status by BotStore.status.collectAsState()
    val serviceOn by BotStore.serviceOn.collectAsState()
    val cycles by BotStore.cycles.collectAsState()
    val captures by BotStore.captures.collectAsState()
    val fixes by BotStore.speedFixes.collectAsState()
    val nextAt by BotStore.nextCheckAt.collectAsState()
    val target by BotStore.targetPreview.collectAsState()
    val sCap by BotStore.sessionCaptures.collectAsState()
    val sStart by BotStore.sessionStart.collectAsState()
    val sEnd by BotStore.sessionEnd.collectAsState()

    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) { delay(500); now = System.currentTimeMillis() }
    }
    val remaining = ((nextAt - now) / 1000).coerceAtLeast(0)
    val elapsed = if (sStart == 0L) 0L else ((if (sEnd > 0L) sEnd else now) - sStart).coerceAtLeast(0L)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("LOD SHINYS", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    if (running) "● RODANDO" else "● PARADO",
                    color = if (running) Green else Color.Gray,
                    fontWeight = FontWeight.Bold
                )
                Text(status, fontSize = 18.sp)
                if (running && nextAt > 0) Text("Próxima checagem em ${remaining}s")
            }
        }

        Card(
            Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(sCap.toString(), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Green)
                    Text("Capturados na sessão", fontSize = 13.sp)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(formatDuration(elapsed), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Green)
                    Text("Tempo rodando", fontSize = 13.sp)
                }
            }
        }

        target?.let { bmp ->
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Pokémon alvo",
                        modifier = Modifier.size(72.dp)
                    )
                    Column {
                        Text("Pokémon alvo", fontWeight = FontWeight.Bold, color = Green)
                        Text(
                            "Lido da coluna esquerda ao iniciar. O bot só captura o de mesmo formato (a cor pode mudar, como no shiny).",
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        if (!serviceOn) {
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF3B1212))
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Serviço de acessibilidade desativado", fontWeight = FontWeight.Bold)
                    Text("Ative o LOD SHINYS na lista para o bot poder tocar e ler a tela.")
                    Button(onClick = {
                        ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }) { Text("Abrir Acessibilidade") }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard("Ciclos", cycles)
            StatCard("Capturas", captures)
            StatCard("Avisos", fixes)
        }

        Button(
            onClick = { BotService.instance?.toggle() },
            enabled = serviceOn,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = if (running) Red else Green)
        ) { Text(if (running) "PARAR BOT" else "INICIAR BOT", fontWeight = FontWeight.Bold) }

        OutlinedButton(
            onClick = { BotService.instance?.showPanel() },
            enabled = serviceOn,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Mostrar botão flutuante") }

        OutlinedButton(
            onClick = { startCalibrationDelayed(ctx) },
            enabled = serviceOn,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Calibrar toques (abra o jogo)") }

        TextButton(onClick = { BotStore.resetCounters() }) { Text("Zerar contadores") }

        Text(
            "Dica: adicione o atalho \"LOD SHINYS\" nas configurações rápidas para ligar e desligar o bot sem abrir o app.",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

private fun startCalibrationDelayed(ctx: Context) {
    Toast.makeText(ctx, "Abra o jogo. A calibração começa em 8 segundos.", Toast.LENGTH_LONG).show()
    Handler(Looper.getMainLooper()).postDelayed({ BotService.instance?.startCalibration() }, 8000)
}

@Composable
fun RowScope.StatCard(label: String, value: Int) {
    Card(
        Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value.toString(), fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Green)
            Text(label, fontSize = 13.sp)
        }
    }
}

// ============================ AJUSTES ============================
@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Ajustes", fontSize = 28.sp, fontWeight = FontWeight.Bold)

        SectionCard("Tempos") {
            SettingSlider("Espera após clicar na coluna esquerda", "wait_check", 25, 5, 120, "s")
            SettingSlider("Espera após o duplo toque no Pokémon da direita", "wait_tap_right", 5, 1, 20, "s")
        }

        SectionCard("Capturas") {
            SettingSlider(
                "Quantidade de capturas", "target_captures", 1, 0, 200, "",
                "0 = loop infinito. O bot só para quando atingir a quantidade (ou algum limite abaixo)."
            )
            SettingSlider("Espera após cada captura", "wait_after_capture", 8, 3, 30, "s")
        }

        SectionCard("Alvo") {
            SettingSwitch("Capturar só o Pokémon igual ao da esquerda", "match_enabled", true)
            SettingSlider(
                "Tolerância", "match_tolerance", 10, 2, 40, "",
                "Aumente se ele não reconhecer o igual; diminua se confundir com outros. O Log mostra a distância de cada espaço da direita (menor = mais parecido)."
            )
            SettingSlider(
                "Peso do brilho/cor", "match_color", 30, 0, 100, "%",
                "0 = compara só o formato (melhor para normal x shiny). Aumente só se ele confundir Pokémon de formato parecido."
            )
        }

        SectionCard("Detecção") {
            SettingSlider(
                "Sensibilidade", "sensitivity", 60, 10, 300, "",
                "Menor = detecta mais fácil. Se ele achar Pokémon onde não tem, aumente."
            )
        }

        SectionCard("Limites (0 = sem limite)") {
            SettingSlider("Parar após", "max_minutes", 0, 0, 240, " min")
            SettingSlider("Parar após", "max_cycles", 0, 0, 500, " ciclos")
        }

        SectionCard("Avisos") {
            SettingSwitch("Notificação e vibração ao terminar", "notify", true)
        }

        SectionCard("Calibração") {
            Text(
                "Use \"Calibrar toques\" na tela Início ou o botão ◎ do painel flutuante.",
                fontSize = 13.sp
            )
            OutlinedButton(onClick = {
                BotStore.resetPoints()
                Toast.makeText(ctx, "Posições restauradas", Toast.LENGTH_SHORT).show()
            }) { Text("Restaurar posições padrão") }
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, color = Green)
            content()
        }
    }
}

@Composable
fun SettingSlider(
    title: String, key: String, def: Int, min: Int, max: Int, unit: String, hint: String = ""
) {
    var v by remember { mutableStateOf(BotStore.getInt(key, def).toFloat()) }
    Column {
        Text("$title: ${v.toInt()}$unit")
        Slider(
            value = v,
            onValueChange = { v = it },
            onValueChangeFinished = { BotStore.putInt(key, v.toInt()) },
            valueRange = min.toFloat()..max.toFloat()
        )
        if (hint.isNotEmpty()) Text(hint, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SettingSwitch(title: String, key: String, def: Boolean) {
    var on by remember { mutableStateOf(BotStore.getBool(key, def)) }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = { on = it; BotStore.putBool(key, it) })
    }
}

// ============================ LOG ============================
@Composable
fun LogScreen() {
    val logs by BotStore.logs.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Log", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = { BotStore.clearLog() }) { Text("Limpar") }
        }
        if (logs.isEmpty()) {
            Text("Nada por aqui ainda.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(logs) { line -> Text(line, fontSize = 14.sp) }
            }
        }
    }
}
