package com.bot.pogo

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        fun label(t: String) = TextView(this).apply { text = t; textSize = 16f; setPadding(0, 32, 0, 0) }
        fun field(v: Int) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(v.toString())
        }

        layout.addView(TextView(this).apply {
            text = "1) Abra a Acessibilidade e ative o PogoBot\n2) Abra o jogo e use o botão flutuante INICIAR"
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Abrir Acessibilidade"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        layout.addView(Button(this).apply {
            text = "Mostrar botão flutuante"
            setOnClickListener { BotService.instance?.showPanel() }
        })

        layout.addView(label("Segundos de espera depois de clicar na coluna esquerda:"))
        val f1 = field(prefs.getInt("wait_check", 25))
        layout.addView(f1)

        layout.addView(label("Segundos de espera depois de clicar no Pokémon da direita:"))
        val f2 = field(prefs.getInt("wait_tap_right", 5))
        layout.addView(f2)

        layout.addView(Button(this).apply {
            text = "Salvar tempos"
            setOnClickListener {
                val a = f1.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 25
                val b = f2.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 5
                prefs.edit().putInt("wait_check", a).putInt("wait_tap_right", b).apply()
                f1.setText(a.toString()); f2.setText(b.toString())
                Toast.makeText(this@MainActivity, "Salvo: ${a}s e ${b}s", Toast.LENGTH_SHORT).show()
            }
        })
        setContentView(layout)
    }
}
