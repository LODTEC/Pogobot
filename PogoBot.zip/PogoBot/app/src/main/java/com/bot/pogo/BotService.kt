package com.bot.pogo

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class BotService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotService? = null
    }

    private val THROW_FROM = PointF(0.50f, 0.85f)
    private val THROW_TO = PointF(0.50f, 0.45f)
    private val WAIT_AFTER_THROW = 1500L
    private val WATCH_EVERY = 2500L
    private val START_DELAY = 3000L

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var toggleBtn: TextView? = null
    private var banner: TextView? = null
    private var calibView: FrameLayout? = null
    private var startedAt = 0L
    private var cooldownLogged = false
    private class Sig(val cov: FloatArray, val col: FloatArray)
    private var refSig: Sig? = null
    private var targetSlot = 0
    private val GRID = 8
    private val SLOT_PITCH = 0.0489f   // distância vertical entre os espaços da coluna (fração da tela)
    private var hud: TextView? = null
    private val hudHandler = Handler(Looper.getMainLooper())
    private val hudRunnable = object : Runnable {
        override fun run() {
            updateHud()
            hudHandler.postDelayed(this, 1000)
        }
    }

    private fun running() = BotStore.running.value
    private fun cfg(key: String, def: Int) = BotStore.getInt(key, def)
    private fun screenW() = wm.currentWindowMetrics.bounds.width()
    private fun screenH() = wm.currentWindowMetrics.bounds.height()

    // ================= ciclo de vida =================
    override fun onServiceConnected() {
        BotStore.init(this)
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        BotStore.running.value = false
        BotStore.serviceOn.value = true
        BotStore.setStatus("Parado")
        BotStore.log("Serviço de acessibilidade conectado")
        showPanel()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        handler.removeCallbacksAndMessages(null)
        removeBanner()
        closeCalibration()
        hideHud()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        toggleBtn = null
        BotStore.running.value = false
        BotStore.serviceOn.value = false
        instance = null
    }

    // ================= painel flutuante =================
    private fun chip(label: String, color: Int, onClick: () -> Unit) = TextView(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(color)
        setPadding(28, 18, 28, 18)
        textSize = 15f
        setOnClickListener { onClick() }
    }

    fun showPanel() {
        if (panel != null) return
        val toggle = chip("▶ INICIAR", Color.argb(210, 30, 120, 30)) { toggle() }
        val calib = chip("◎", Color.argb(210, 40, 70, 140)) { startCalibration() }
        val close = chip("✕", Color.argb(210, 60, 60, 60)) { hidePanel() }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(toggle); addView(calib); addView(close)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 8
            y = (screenH() * 0.45f).toInt()
        }
        wm.addView(box, lp)
        panel = box
        toggleBtn = toggle
        updateToggleButton()
        showHud()
    }

    fun hidePanel() {
        if (running()) stopBot("Parado")
        removeBanner()
        hideHud()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        toggleBtn = null
    }

    // ---------- HUD: capturas e tempo da sessão ----------
    private fun showHud() {
        if (hud != null) return
        val t = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(170, 0, 0, 0))
            setPadding(24, 10, 24, 10)
            textSize = 14f
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = (screenH() * 0.05f).toInt()
        }
        wm.addView(t, lp)
        hud = t
        hudHandler.post(hudRunnable)
    }

    private fun hideHud() {
        hudHandler.removeCallbacks(hudRunnable)
        hud?.let { runCatching { wm.removeView(it) } }
        hud = null
    }

    private fun updateHud() {
        val start = BotStore.sessionStart.value
        val end = BotStore.sessionEnd.value
        val elapsed = if (start == 0L) 0L else ((if (end > 0L) end else System.currentTimeMillis()) - start)
        hud?.text = "Capturados: ${BotStore.sessionCaptures.value}   ⏱ ${formatDuration(elapsed)}"
    }

    private fun updateToggleButton() {
        toggleBtn?.apply {
            if (running()) {
                text = "■ PARAR"
                setBackgroundColor(Color.argb(210, 160, 30, 30))
            } else {
                text = "▶ INICIAR"
                setBackgroundColor(Color.argb(210, 30, 120, 30))
            }
        }
    }

    // ================= controle do bot =================
    fun toggle() {
        if (running()) stopBot("Parado") else startBot()
    }

    fun startBot() {
        removeBanner()
        closeCalibration()
        BotStore.running.value = true
        startedAt = SystemClock.elapsedRealtime()
        BotStore.sessionCaptures.value = 0
        BotStore.sessionStart.value = System.currentTimeMillis()
        BotStore.sessionEnd.value = 0L
        BotStore.setStatus("Iniciando em ${START_DELAY / 1000}s…")
        BotStore.log("Bot iniciado")
        updateToggleButton()
        handler.postDelayed({ watch() }, START_DELAY + WATCH_EVERY)
        handler.postDelayed({
            if (BotStore.getBool("match_enabled", true)) {
                captureReference(1)
            } else {
                refSig = null
                BotStore.targetPreview.value = null
                tick()
            }
        }, START_DELAY)
    }

    fun stopBot(reason: String) {
        if (running()) {
            BotStore.log(reason)
            BotStore.sessionEnd.value = System.currentTimeMillis()
        }
        BotStore.running.value = false
        handler.removeCallbacksAndMessages(null)
        BotStore.nextCheckAt.value = 0L
        BotStore.setStatus(reason)
        updateToggleButton()
    }

    private fun finishWithLimit(reason: String) {
        stopBot(reason)
        alert("LOD SHINYS", reason)
    }

    // Passo 1: clica no 1º da esquerda e espera
    private fun tick() {
        if (!running()) return
        val maxMin = cfg("max_minutes", 0)
        if (maxMin > 0 && SystemClock.elapsedRealtime() - startedAt >= maxMin * 60_000L) {
            finishWithLimit("Tempo limite atingido"); return
        }
        val maxCyc = cfg("max_cycles", 0)
        if (maxCyc > 0 && BotStore.cycles.value >= maxCyc) {
            finishWithLimit("Limite de ciclos atingido"); return
        }
        BotStore.addCycle()
        tap(BotStore.point("left"))
        val w = cfg("wait_check", 25)
        BotStore.setStatus("Aguardando ${w}s por Pokémon…")
        BotStore.nextCheckAt.value = System.currentTimeMillis() + w * 1000L
        handler.postDelayed({ check() }, w * 1000L)
    }

    // Passo 2: olha a coluna direita
    private fun check() {
        if (!running()) return
        BotStore.nextCheckAt.value = 0L
        BotStore.setStatus("Verificando coluna direita…")
        shot { bmp ->
            if (!running()) return@shot
            if (bmp == null) {
                handler.postDelayed({ check() }, 1000)
                return@shot
            }
            val dlg = detectDialog(bmp)
            if (dlg != null) {
                dismissDialog(dlg)
                handler.postDelayed({ check() }, 1500)
                return@shot
            }
            val slot = findTarget(bmp)
            if (slot >= 0) catchSequence(slot) else tick()
        }
    }

    // Vigia: avisos do jogo podem aparecer a qualquer momento
    private fun watch() {
        if (!running()) return
        shot { bmp ->
            if (running() && bmp != null) {
                val dlg = detectDialog(bmp)
                if (dlg != null) dismissDialog(dlg)
            }
        }
        handler.postDelayed({ watch() }, WATCH_EVERY)
    }

    private fun dismissDialog(kind: String) {
        tap(BotStore.point(kind))
        BotStore.addSpeedFix()
        BotStore.log(if (kind == "weather") "Alerta meteorológico fechado" else "Tela de velocidade fechada")
    }

    // Passo 3: captura (duplo toque no Pokémon alvo da direita abre a tela de captura)
    private fun catchSequence(slot: Int) {
        targetSlot = slot
        BotStore.setStatus("Pokémon alvo encontrado! Abrindo captura…")
        BotStore.log("Pokémon alvo no espaço ${slot + 1} da coluna direita")
        openEncounter(1)
    }

    private fun openEncounter(attempt: Int) {
        if (!running()) return
        val r = BotStore.point("right")
        doubleTap(PointF(r.x, r.y + targetSlot * SLOT_PITCH))
        BotStore.setStatus("Abrindo captura (tentativa $attempt/3)…")
        handler.postDelayed({ verifyEncounter(attempt) }, cfg("wait_tap_right", 5) * 1000L)
    }

    private fun verifyEncounter(attempt: Int) {
        if (!running()) return
        shot { bmp ->
            if (!running()) return@shot
            val dlg = if (bmp != null) detectDialog(bmp) else null
            when {
                bmp == null -> handler.postDelayed({ verifyEncounter(attempt) }, 1000)
                dlg != null -> {
                    dismissDialog(dlg)
                    handler.postDelayed({ openEncounter(attempt) }, 1500)
                }
                isEncounter(bmp) -> { cooldownLogged = false; waitCooldownThenThrow(0) }
                attempt < 3 -> {
                    BotStore.log("Captura não abriu (tentativa $attempt)")
                    openEncounter(attempt + 1)
                }
                else -> {
                    stopBot("A tela de captura não abriu. Calibre a coluna direita (◎).")
                    alert("LOD SHINYS", "A tela de captura não abriu. Calibre a coluna direita.")
                }
            }
        }
    }

    // Temporizador do canto superior esquerdo: vermelho = em espera, verde = liberado
    private fun cooldownActive(bmp: Bitmap): Boolean {
        val x0 = (bmp.width * 0.095f).toInt()
        val x1 = (bmp.width * 0.225f).toInt()
        val y0 = (bmp.height * 0.060f).toInt()
        val y1 = (bmp.height * 0.085f).toInt()
        var red = 0
        var green = 0
        for (y in y0 until y1) {
            for (x in x0 until x1) {
                val p = bmp.getPixel(x, y)
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                if (r > 170 && r > g + 70 && r > b + 70) red++
                else if (g > 170 && g > r + 40) green++
            }
        }
        return red >= 15 && red > green
    }

    // Na tela de captura: espera o temporizador ficar verde e só então joga a Pokébola
    private fun waitCooldownThenThrow(misses: Int) {
        if (!running()) return
        shot { bmp ->
            if (!running()) return@shot
            val dlg = if (bmp != null) detectDialog(bmp) else null
            when {
                bmp == null -> handler.postDelayed({ waitCooldownThenThrow(misses) }, 1000)
                dlg != null -> {
                    dismissDialog(dlg)
                    handler.postDelayed({ waitCooldownThenThrow(misses) }, 1500)
                }
                !isEncounter(bmp) -> {
                    if (misses >= 2) {
                        BotStore.log("Saiu da tela de captura durante a espera")
                        tick()
                    } else {
                        handler.postDelayed({ waitCooldownThenThrow(misses + 1) }, 1000)
                    }
                }
                cooldownActive(bmp) -> {
                    BotStore.setStatus("Aguardando o temporizador zerar…")
                    if (!cooldownLogged) {
                        cooldownLogged = true
                        BotStore.log("Temporizador vermelho: esperando zerar para jogar")
                    }
                    handler.postDelayed({ waitCooldownThenThrow(0) }, 2000)
                }
                else -> throwBall()
            }
        }
    }

    private fun throwBall() {
        BotStore.setStatus("Lançando Pokébola…")
        swipe(THROW_FROM, THROW_TO)
        handler.postDelayed({ finishCapture() }, WAIT_AFTER_THROW)
    }

    // Tela de captura: a Pokébola grande e vermelha na parte de baixo
    private fun isRed(bmp: Bitmap, x: Float, y: Float): Boolean {
        val p = pixelAt(bmp, x, y)
        val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
        return r > 110 && r > g + 60 && r > b + 60
    }

    private fun isEncounter(bmp: Bitmap): Boolean =
        isRed(bmp, 0.50f, 0.865f) && isRed(bmp, 0.44f, 0.875f)

    private fun finishCapture() {
        BotStore.addCapture()
        BotStore.sessionCaptures.value += 1
        val sc = BotStore.sessionCaptures.value
        val target = cfg("target_captures", 1)
        if (target == 0 || sc < target) {
            val progress = if (target == 0) "$sc" else "$sc/$target"
            BotStore.log("Captura $progress concluída")
            BotStore.setStatus("Captura $progress concluída. Continuando…")
            handler.postDelayed({ tick() }, cfg("wait_after_capture", 8) * 1000L)
        } else {
            stopBot("Pokémon capturado com sucesso")
            showBanner("Pokémon capturado com sucesso")
            alert("LOD SHINYS", "Pokémon capturado com sucesso")
        }
    }

    // ================= avisos =================
    private fun alert(title: String, text: String) {
        if (!BotStore.getBool("notify", true)) return
        runCatching {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("pogo", "LOD SHINYS", NotificationManager.IMPORTANCE_HIGH)
            )
            val n = Notification.Builder(this, "pogo")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setAutoCancel(true)
                .build()
            nm.notify(1, n)
        }
        runCatching {
            val v = getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createOneShot(600, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }

    private fun showBanner(text: String) {
        removeBanner()
        val t = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(230, 20, 100, 20))
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(48, 36, 48, 36)
            setOnClickListener { removeBanner() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(t, lp)
        banner = t
    }

    private fun removeBanner() {
        banner?.let { runCatching { wm.removeView(it) } }
        banner = null
    }

    // ================= calibração por toque =================
    fun startCalibration() {
        if (calibView != null) return
        if (running()) stopBot("Parado para calibrar")
        val steps = listOf(
            "left" to "1/3 • Toque no 1º Pokémon da coluna ESQUERDA",
            "right" to "2/3 • Toque no 1º espaço da coluna DIREITA (onde o Pokémon aparece)",
            "speed" to "3/3 • Toque no botão verde \"SOU UM PASSAGEIRO\" (ou toque em Pular)"
        )
        var idx = 0
        val info = TextView(this).apply {
            text = steps[0].second
            setTextColor(Color.WHITE)
            textSize = 18f
            setPadding(0, 0, 0, 24)
        }

        fun next() {
            idx++
            if (idx >= steps.size) {
                closeCalibration()
                BotStore.log("Calibração concluída")
                Toast.makeText(this, "Calibração salva", Toast.LENGTH_SHORT).show()
            } else {
                info.text = steps[idx].second
            }
        }

        val skip = chip("Pular", Color.argb(255, 70, 70, 70)) { next() }
        val cancel = chip("Cancelar", Color.argb(255, 160, 30, 30)) { closeCalibration() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(skip)
            addView(cancel)
        }
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.argb(235, 15, 23, 42))
            setPadding(32, 72, 32, 32)
            isClickable = true
            addView(info)
            addView(row)
        }
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(110, 0, 0, 0))
            setOnTouchListener { _, e ->
                if (e.action == MotionEvent.ACTION_UP && idx < steps.size) {
                    val fx = (e.rawX / screenW()).coerceIn(0f, 1f)
                    val fy = (e.rawY / screenH()).coerceIn(0f, 1f)
                    BotStore.setPoint(steps[idx].first, fx, fy)
                    BotStore.log("Calibrado '${steps[idx].first}': %.3f, %.3f".format(fx, fy))
                    next()
                }
                true
            }
            addView(
                bar,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP
                )
            )
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(root, lp)
        calibView = root
        BotStore.log("Calibração iniciada")
    }

    private fun closeCalibration() {
        calibView?.let { runCatching { wm.removeView(it) } }
        calibView = null
    }

    // ================= captura de tela e detecção =================
    private fun shot(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                cb(bmp)
            }
            override fun onFailure(errorCode: Int) { cb(null) }
        })
    }

    private fun pixelAt(bmp: Bitmap, x: Float, y: Float): Int {
        val px = (x * bmp.width).toInt().coerceIn(0, bmp.width - 1)
        val py = (y * bmp.height).toInt().coerceIn(0, bmp.height - 1)
        return bmp.getPixel(px, py)
    }

    // Painel liso (branco ou escuro) cobrindo a tela = algum aviso do jogo
    private fun panelOk(bmp: Bitmap): Boolean {
        val pts = listOf(
            0.10f to 0.31f, 0.10f to 0.42f, 0.10f to 0.60f, 0.10f to 0.70f, 0.35f to 0.31f
        )
        val cols = pts.map { pixelAt(bmp, it.first, it.second) }
        val diff = listOf(
            cols.maxOf { Color.red(it) } - cols.minOf { Color.red(it) },
            cols.maxOf { Color.green(it) } - cols.minOf { Color.green(it) },
            cols.maxOf { Color.blue(it) } - cols.minOf { Color.blue(it) }
        ).max()
        val first = cols[0]
        val avg = (Color.red(first) + Color.green(first) + Color.blue(first)) / 3
        return diff <= 22 && (avg > 225 || avg < 80)
    }

    private fun isGreen(bmp: Bitmap, x: Float, y: Float): Boolean {
        val c = pixelAt(bmp, x, y)
        val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
        return g > 170 && g > r + 10 && g > b + 15
    }

    // Retorna "speed" (andando rápido), "weather" (alerta meteorológico) ou null
    private fun detectDialog(bmp: Bitmap): String? {
        if (!panelOk(bmp)) return null
        if (isGreen(bmp, 0.19f, 0.656f) || isGreen(bmp, 0.22f, 0.656f)) return "speed"
        if (isGreen(bmp, 0.29f, 0.677f) || isGreen(bmp, 0.31f, 0.677f)) return "weather"
        return null
    }

    // ================= reconhecimento do Pokémon alvo =================
    // Recorta o ícone de um espaço da lista (centro em cx, cy em fração da tela)
    private fun slotBox(bmp: Bitmap, cx: Float, cy: Float, dx: Int, dy: Int): IntArray? {
        val w = (bmp.width * 0.075f).toInt()
        val h = (bmp.height * 0.038f).toInt()
        val x0 = (cx * bmp.width).toInt() - w / 2 + dx
        val y0 = (cy * bmp.height).toInt() - h / 2 + dy
        if (x0 < 0 || y0 < 0 || x0 + w > bmp.width || y0 + h > bmp.height) return null
        return intArrayOf(x0, y0, w, h)
    }

    // "Assinatura" do ícone: formato (cobertura) e brilho médio do sprite em uma grade.
    // Não usa a cor em si, então o Pokémon normal e o shiny (mesmo formato, cor diferente) combinam.
    // O fundo é estimado pela borda do recorte, então funciona nas duas colunas.
    private fun signature(bmp: Bitmap, cx: Float, cy: Float, dx: Int, dy: Int): Sig? {
        val box = slotBox(bmp, cx, cy, dx, dy) ?: return null
        val x0 = box[0]; val y0 = box[1]; val w = box[2]; val h = box[3]
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, x0, y0, w, h)

        var sr = 0L; var sg = 0L; var sb = 0L; var n = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                if (x < 4 || y < 4 || x >= w - 4 || y >= h - 4) {
                    val p = px[y * w + x]
                    sr += Color.red(p); sg += Color.green(p); sb += Color.blue(p); n++
                }
            }
        }
        val r0 = (sr / n).toInt(); val g0 = (sg / n).toInt(); val b0 = (sb / n).toInt()

        val cnt = IntArray(GRID * GRID)
        val lum = FloatArray(GRID * GRID)
        var fg = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                val p = px[y * w + x]
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                val diff = Math.abs(r - r0) + Math.abs(g - g0) + Math.abs(b - b0)
                if (diff > 120) {
                    fg++
                    val cell = (y * GRID / h) * GRID + (x * GRID / w)
                    cnt[cell]++
                    lum[cell] += (0.299f * r + 0.587f * g + 0.114f * b) / 255f
                }
            }
        }
        if (fg < w * h * 0.06f) return null // espaço vazio

        val cellArea = ((w / GRID) * (h / GRID)).toFloat()
        val cov = FloatArray(GRID * GRID)
        for (i in 0 until GRID * GRID) {
            cov[i] = minOf(1f, cnt[i] / cellArea)
            if (cnt[i] > 0) {
                lum[i] = lum[i] / cnt[i].toFloat()
            }
        }
        return Sig(cov, lum)
    }

    // wc = peso do brilho (0 = só o formato)
    private fun distance(a: Sig, b: Sig, wc: Float): Float {
        var d = 0f
        for (i in 0 until GRID * GRID) {
            val dc = a.cov[i] - b.cov[i]
            d += dc * dc
            val m = minOf(a.cov[i], b.cov[i])
            if (m > 0f) {
                val dl = a.col[i] - b.col[i]
                d += m * wc * dl * dl
            }
        }
        return d / (GRID * GRID)
    }

    // Ao iniciar: lê o Pokémon do 1º espaço da coluna esquerda e guarda como alvo
    private fun captureReference(attempt: Int) {
        if (!running()) return
        BotStore.setStatus("Lendo o Pokémon da coluna esquerda…")
        shot { bmp ->
            if (!running()) return@shot
            if (bmp == null) {
                if (attempt < 5) handler.postDelayed({ captureReference(attempt + 1) }, 1000)
                else failReference()
                return@shot
            }
            val dlg = detectDialog(bmp)
            if (dlg != null && attempt < 5) {
                dismissDialog(dlg)
                handler.postDelayed({ captureReference(attempt + 1) }, 1500)
                return@shot
            }
            val left = BotStore.point("left")
            val sig = signature(bmp, left.x, left.y, 0, 0)
            val box = slotBox(bmp, left.x, left.y, 0, 0)
            if (sig == null || box == null) {
                failReference()
                return@shot
            }
            refSig = sig
            BotStore.targetPreview.value = runCatching {
                Bitmap.createBitmap(bmp, box[0], box[1], box[2], box[3])
            }.getOrNull()
            BotStore.log("Pokémon alvo lido da coluna esquerda")
            tick()
        }
    }

    private fun failReference() {
        stopBot("Não consegui ler o Pokémon da coluna esquerda. Calibre (◎).")
        alert("LOD SHINYS", "Não consegui ler o Pokémon da coluna esquerda.")
    }

    // Procura na coluna direita o espaço com o Pokémon igual ao alvo. Retorna o índice (0..5) ou -1.
    private fun findTarget(bmp: Bitmap): Int {
        val ref = refSig
        if (!BotStore.getBool("match_enabled", true) || ref == null) {
            return if (hasPokemon(bmp)) 0 else -1
        }
        val tol = cfg("match_tolerance", 10) / 100f
        val wc = cfg("match_color", 30) / 100f
        val right = BotStore.point("right")
        var best = -1
        var bestD = Float.MAX_VALUE
        val dists = ArrayList<String>()
        for (k in 0..5) {
            val cy = right.y + k * SLOT_PITCH
            if (cy > 0.64f) break
            var dMin = Float.MAX_VALUE
            var any = false
            for (dy in intArrayOf(-6, 0, 6)) {
                for (dx in intArrayOf(-6, 0, 6)) {
                    val sig = signature(bmp, right.x, cy, dx, dy) ?: continue
                    any = true
                    dMin = minOf(dMin, distance(ref, sig, wc))
                }
            }
            if (!any) continue
            dists.add("%d:%.2f".format(k + 1, dMin))
            if (dMin <= tol && dMin < bestD) { best = k; bestD = dMin }
        }
        if (dists.isNotEmpty()) {
            BotStore.log("Direita [${dists.joinToString(" ")}] limite %.2f".format(tol))
        }
        return best
    }

    // Pixel "aceso" = claro e não azulado (ignora cubos/pokéstops azuis)
    private fun lit(bmp: Bitmap, x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) return false
        val p = bmp.getPixel(x, y)
        val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
        val bright = r > 140 || g > 140 || b > 140
        val bluish = b > r + 35 && b >= g
        return bright && !bluish
    }

    // A área de detecção acompanha o ponto calibrado da coluna direita
    private fun detectRect(): RectF {
        val p = BotStore.point("right")
        return RectF(p.x - 0.045f, p.y - 0.025f, p.x + 0.055f, p.y + 0.040f)
    }

    // Só conta áreas "grossas" (sprites). Círculos/linhas finas do mapa são ignorados.
    private fun hasPokemon(bmp: Bitmap): Boolean {
        val r = detectRect()
        val x0 = (bmp.width * r.left.coerceIn(0f, 1f)).toInt()
        val x1 = (bmp.width * r.right.coerceIn(0f, 1f)).toInt()
        val y0 = (bmp.height * r.top.coerceIn(0f, 1f)).toInt()
        val y1 = (bmp.height * r.bottom.coerceIn(0f, 1f)).toInt()
        val d = 7
        var count = 0
        for (y in y0 until y1 step 2) {
            for (x in x0 until x1 step 2) {
                if (lit(bmp, x, y) && lit(bmp, x - d, y) && lit(bmp, x + d, y) &&
                    lit(bmp, x, y - d) && lit(bmp, x, y + d)) count++
            }
        }
        return count > cfg("sensitivity", 60)
    }

    // ================= gestos =================
    private fun tap(p: PointF) {
        val path = Path().apply { moveTo(p.x * screenW(), p.y * screenH()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(g, null, null)
    }

    private fun doubleTap(p: PointF) {
        val path = Path().apply { moveTo(p.x * screenW(), p.y * screenH()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50))
            .addStroke(GestureDescription.StrokeDescription(path, 140, 50))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun swipe(a: PointF, b: PointF) {
        val path = Path().apply {
            moveTo(a.x * screenW(), a.y * screenH())
            lineTo(b.x * screenW(), b.y * screenH())
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        dispatchGesture(g, null, null)
    }
}
