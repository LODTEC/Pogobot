package com.bot.pogo

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView

class BotService : AccessibilityService() {

    // ================= CONFIG (frações da tela, 0..1) =================
    private val LEFT_FIRST = PointF(0.776f, 0.359f)   // 1º pokémon coluna esquerda
    private val RIGHT_FIRST = PointF(0.920f, 0.360f)  // 1º pokémon coluna direita
    private val PLAYER = PointF(0.500f, 0.620f)       // personagem no mapa
    private val THROW_FROM = PointF(0.500f, 0.850f)
    private val THROW_TO = PointF(0.500f, 0.450f)
    private val DETECT = RectF(0.875f, 0.335f, 0.975f, 0.400f) // só o 1º slot da coluna direita
    private val SPEED_BTN = PointF(0.400f, 0.656f)    // botão verde "SOU UM PASSAGEIRO"
    private val WATCH_EVERY = 2500L                   // de quanto em quanto tempo procura a tela de velocidade
    private val DETECT_MIN_PIXELS = 60                // sensibilidade (pixels 'grossos' necessários)
    private val WAIT_AFTER_TAP_PLAYER = 3000L
    private val WAIT_AFTER_THROW = 1500L
    // ===================================================================

    // Tempos escolhidos dentro do app (segundos)
    private fun waitCheck(): Long =
        getSharedPreferences("cfg", MODE_PRIVATE).getInt("wait_check", 25) * 1000L
    private fun waitAfterTapRight(): Long =
        getSharedPreferences("cfg", MODE_PRIVATE).getInt("wait_tap_right", 5) * 1000L

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var button: TextView? = null
    private var panel: LinearLayout? = null

    companion object {
        var instance: BotService? = null
    }
    private var banner: TextView? = null
    private var running = false

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    fun showPanel() {
        if (panel != null) return
        val b = TextView(this).apply {
            text = "▶ INICIAR"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(210, 30, 120, 30))
            setPadding(28, 18, 28, 18)
            textSize = 15f
            setOnClickListener { toggle() }
        }
        val close = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(210, 60, 60, 60))
            setPadding(28, 18, 28, 18)
            textSize = 15f
            setOnClickListener { hidePanel() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(b)
            addView(close)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 8
            y = (screenH() * 0.45f).toInt()
        }
        wm.addView(box, lp)
        button = b
        panel = box
    }

    // Desliga o bot e remove os botões da tela
    fun hidePanel() {
        stopBot()
        removeBanner()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        button = null
    }

    private fun toggle() {
        if (running) stopBot() else startBot()
    }

    private fun startBot() {
        removeBanner()
        running = true
        button?.text = "■ PARAR"
        button?.setBackgroundColor(Color.argb(210, 160, 30, 30))
        handler.postDelayed({ watch() }, WATCH_EVERY)
        tick()
    }

    private fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
        button?.text = "▶ INICIAR"
        button?.setBackgroundColor(Color.argb(210, 30, 120, 30))
    }

    // Passo 1: clica no 1º da esquerda e espera
    private fun tick() {
        if (!running) return
        tap(LEFT_FIRST)
        handler.postDelayed({ check() }, waitCheck())
    }

    private fun shot(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                cb(bmp)
            }
            override fun onFailure(errorCode: Int) { cb(null) }
        })
    }

    private fun pixelAt(bmp: Bitmap, x: Float, y: Float): Int {
        val px = (x * bmp.width).toInt().coerceIn(0, bmp.width - 1)
        val py = (y * bmp.height).toInt().coerceIn(0, bmp.height - 1)
        return bmp.getPixel(px, py)
    }

    // Tela "Está andando muito rápido!": painel branco + botão verde
    // (pontos escolhidos longe do botão flutuante do bot e dos textos)
    private fun isWhite(bmp: Bitmap, x: Float, y: Float): Boolean {
        val p = pixelAt(bmp, x, y)
        return Color.red(p) > 225 && Color.green(p) > 225 && Color.blue(p) > 225
    }

    private fun isGreen(bmp: Bitmap, x: Float, y: Float): Boolean {
        val c = pixelAt(bmp, x, y)
        val r = Color.red(c); val g = Color.green(c); val b = Color.blue(c)
        return g > 170 && g > r + 10 && g > b + 15
    }

    private fun isSpeedDialog(bmp: Bitmap): Boolean {
        val whitePoints = listOf(
            0.10f to 0.31f, 0.10f to 0.42f, 0.10f to 0.60f, 0.10f to 0.70f, 0.35f to 0.31f
        )
        val whiteCount = whitePoints.count { isWhite(bmp, it.first, it.second) }
        val greenOk = isGreen(bmp, 0.19f, 0.656f) || isGreen(bmp, 0.22f, 0.656f)
        return whiteCount >= 4 && greenOk
    }

    // Vigia: a tela de velocidade pode aparecer a qualquer momento
    private fun watch() {
        if (!running) return
        shot { bmp ->
            if (running && bmp != null && isSpeedDialog(bmp)) tap(SPEED_BTN)
        }
        handler.postDelayed({ watch() }, WATCH_EVERY)
    }

    // Passo 2: olha a coluna direita
    private fun check() {
        if (!running) return
        shot { bmp ->
            if (!running) return@shot
            when {
                bmp == null -> handler.postDelayed({ check() }, 1000)
                isSpeedDialog(bmp) -> {
                    tap(SPEED_BTN)
                    handler.postDelayed({ check() }, 1500)
                }
                hasPokemon(bmp) -> catchSequence()
                else -> tick()
            }
        }
    }

    // Um pixel "aceso" = claro e não azulado (ignora cubos/pokéstops azuis)
    private fun lit(bmp: Bitmap, x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) return false
        val p = bmp.getPixel(x, y)
        val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
        val bright = r > 140 || g > 140 || b > 140
        val bluish = b > r + 35 && b >= g
        return bright && !bluish
    }

    // Só conta áreas "grossas" (sprites). Círculos/linhas finas do mapa são ignorados.
    private fun hasPokemon(bmp: Bitmap): Boolean {
        val x0 = (bmp.width * DETECT.left).toInt()
        val x1 = (bmp.width * DETECT.right).toInt()
        val y0 = (bmp.height * DETECT.top).toInt()
        val y1 = (bmp.height * DETECT.bottom).toInt()
        val d = 7
        var count = 0
        for (y in y0 until y1 step 2) {
            for (x in x0 until x1 step 2) {
                if (lit(bmp, x, y) && lit(bmp, x - d, y) && lit(bmp, x + d, y) &&
                    lit(bmp, x, y - d) && lit(bmp, x, y + d)) count++
            }
        }
        return count > DETECT_MIN_PIXELS
    }

    // Passo 3: captura
    private fun catchSequence() {
        tap(RIGHT_FIRST)
        handler.postDelayed({
            if (!running) return@postDelayed
            tap(PLAYER)
            handler.postDelayed({
                if (!running) return@postDelayed
                swipe(THROW_FROM, THROW_TO)
                handler.postDelayed({ finish() }, WAIT_AFTER_THROW)
            }, WAIT_AFTER_TAP_PLAYER)
        }, waitAfterTapRight())
    }

    private fun finish() {
        stopBot()
        showBanner("Pokémon capturado com sucesso")
    }

    private fun showBanner(text: String) {
        removeBanner()
        val t = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(230, 20, 100, 20))
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(48, 36, 48, 36)
            setOnClickListener { removeBanner() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(t, lp)
        banner = t
    }

    private fun removeBanner() {
        banner?.let { runCatching { wm.removeView(it) } }
        banner = null
    }

    private fun screenW() = wm.currentWindowMetrics.bounds.width()
    private fun screenH() = wm.currentWindowMetrics.bounds.height()

    private fun tap(p: PointF) {
        val path = Path().apply { moveTo(p.x * screenW(), p.y * screenH()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(g, null, null)
    }

    private fun swipe(a: PointF, b: PointF) {
        val path = Path().apply {
            moveTo(a.x * screenW(), a.y * screenH())
            lineTo(b.x * screenW(), b.y * screenH())
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeBanner()
        panel?.let { runCatching { wm.removeView(it) } }
        instance = null
        super.onDestroy()
    }
}
