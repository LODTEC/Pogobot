package com.bot.pogo

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class BotService : AccessibilityService() {

    // ================= CONFIG (frações da tela, 0..1) =================
    private val LEFT_FIRST = PointF(0.776f, 0.359f)   // 1º pokémon coluna esquerda
    private val RIGHT_FIRST = PointF(0.920f, 0.360f)  // 1º pokémon coluna direita
    private val PLAYER = PointF(0.500f, 0.620f)       // personagem no mapa
    private val THROW_FROM = PointF(0.500f, 0.850f)
    private val THROW_TO = PointF(0.500f, 0.450f)
    private val DETECT = RectF(0.870f, 0.345f, 0.975f, 0.640f) // área da coluna direita
    private val DETECT_MIN_PIXELS = 300               // sensibilidade da detecção
    private val WAIT_CHECK = 15000L                   // espera antes de olhar a coluna direita
    private val WAIT_AFTER_TAP_RIGHT = 5000L
    private val WAIT_AFTER_TAP_PLAYER = 3000L
    private val WAIT_AFTER_THROW = 1500L
    // ===================================================================

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var button: TextView? = null
    private var banner: TextView? = null
    private var running = false

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val b = TextView(this).apply {
            text = "▶ INICIAR"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(210, 30, 120, 30))
            setPadding(28, 18, 28, 18)
            textSize = 15f
            setOnClickListener { toggle() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 8
            y = (screenH() * 0.45f).toInt()
        }
        wm.addView(b, lp)
        button = b
    }

    private fun toggle() {
        if (running) stopBot() else startBot()
    }

    private fun startBot() {
        removeBanner()
        running = true
        button?.text = "■ PARAR"
        button?.setBackgroundColor(Color.argb(210, 160, 30, 30))
        tick()
    }

    private fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
        button?.text = "▶ INICIAR"
        button?.setBackgroundColor(Color.argb(210, 30, 120, 30))
    }

    // Passo 1: clica no 1º da esquerda e espera
    private fun tick() {
        if (!running) return
        tap(LEFT_FIRST)
        handler.postDelayed({ check() }, WAIT_CHECK)
    }

    // Passo 2: olha a coluna direita
    private fun check() {
        if (!running) return
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                val found = bmp != null && hasPokemon(bmp)
                if (!running) return
                if (found) catchSequence() else tick()
            }
            override fun onFailure(errorCode: Int) {
                if (running) tick()
            }
        })
    }

    private fun hasPokemon(bmp: Bitmap): Boolean {
        val x0 = (bmp.width * DETECT.left).toInt()
        val x1 = (bmp.width * DETECT.right).toInt()
        val y0 = (bmp.height * DETECT.top).toInt()
        val y1 = (bmp.height * DETECT.bottom).toInt()
        var count = 0
        for (y in y0 until y1 step 2) {
            for (x in x0 until x1 step 2) {
                val p = bmp.getPixel(x, y)
                val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
                val colorful = r > b + 25 || g > b + 25
                val bright = r > 170 && g > 170 && b > 170
                if (colorful || bright) count++
            }
        }
        return count > DETECT_MIN_PIXELS / 4 // step 2 => 1/4 dos pixels
    }

    // Passo 3: captura
    private fun catchSequence() {
        tap(RIGHT_FIRST)
        handler.postDelayed({
            if (!running) return@postDelayed
            tap(PLAYER)
            handler.postDelayed({
                if (!running) return@postDelayed
                swipe(THROW_FROM, THROW_TO)
                handler.postDelayed({ finish() }, WAIT_AFTER_THROW)
            }, WAIT_AFTER_TAP_PLAYER)
        }, WAIT_AFTER_TAP_RIGHT)
    }

    private fun finish() {
        stopBot()
        showBanner("Pokémon capturado com sucesso")
    }

    private fun showBanner(text: String) {
        removeBanner()
        val t = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(230, 20, 100, 20))
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(48, 36, 48, 36)
            setOnClickListener { removeBanner() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(t, lp)
        banner = t
    }

    private fun removeBanner() {
        banner?.let { runCatching { wm.removeView(it) } }
        banner = null
    }

    private fun screenW() = wm.currentWindowMetrics.bounds.width()
    private fun screenH() = wm.currentWindowMetrics.bounds.height()

    private fun tap(p: PointF) {
        val path = Path().apply { moveTo(p.x * screenW(), p.y * screenH()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(g, null, null)
    }

    private fun swipe(a: PointF, b: PointF) {
        val path = Path().apply {
            moveTo(a.x * screenW(), a.y * screenH())
            lineTo(b.x * screenW(), b.y * screenH())
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeBanner()
        button?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }
}
