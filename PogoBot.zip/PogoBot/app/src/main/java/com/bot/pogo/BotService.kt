package com.bot.pogo

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView

class BotService : AccessibilityService() {

    // ================= CONFIG (frações da tela, 0..1) =================
    private val LEFT_FIRST = PointF(0.776f, 0.359f)   // 1º pokémon coluna esquerda
    private val RIGHT_FIRST = PointF(0.920f, 0.360f)  // 1º pokémon coluna direita
    private val PLAYER = PointF(0.500f, 0.620f)       // personagem no mapa
    private val THROW_FROM = PointF(0.500f, 0.850f)
    private val THROW_TO = PointF(0.500f, 0.450f)
    private val DETECT = RectF(0.875f, 0.335f, 0.975f, 0.400f) // só o 1º slot da coluna direita
    private val DETECT_MIN_PIXELS = 60                // sensibilidade (pixels 'grossos' necessários)
    private val WAIT_CHECK = 15000L                   // espera antes de olhar a coluna direita
    private val WAIT_AFTER_TAP_RIGHT = 5000L
    private val WAIT_AFTER_TAP_PLAYER = 3000L
    private val WAIT_AFTER_THROW = 1500L
    // ===================================================================

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var button: TextView? = null
    private var panel: LinearLayout? = null

    companion object {
        var instance: BotService? = null
    }
    private var banner: TextView? = null
    private var running = false

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    fun showPanel() {
        if (panel != null) return
        val b = TextView(this).apply {
            text = "▶ INICIAR"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(210, 30, 120, 30))
            setPadding(28, 18, 28, 18)
            textSize = 15f
            setOnClickListener { toggle() }
        }
        val close = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(210, 60, 60, 60))
            setPadding(28, 18, 28, 18)
            textSize = 15f
            setOnClickListener { hidePanel() }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(b)
            addView(close)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 8
            y = (screenH() * 0.45f).toInt()
        }
        wm.addView(box, lp)
        button = b
        panel = box
    }

    // Desliga o bot e remove os botões da tela
    fun hidePanel() {
        stopBot()
        removeBanner()
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        button = null
    }

    private fun toggle() {
        if (running) stopBot() else startBot()
    }

    private fun startBot() {
        removeBanner()
        running = true
        button?.text = "■ PARAR"
        button?.setBackgroundColor(Color.argb(210, 160, 30, 30))
        tick()
    }

    private fun stopBot() {
        running = false
        handler.removeCallbacksAndMessages(null)
        button?.text = "▶ INICIAR"
        button?.setBackgroundColor(Color.argb(210, 30, 120, 30))
    }

    // Passo 1: clica no 1º da esquerda e espera
    private fun tick() {
        if (!running) return
        tap(LEFT_FIRST)
        handler.postDelayed({ check() }, WAIT_CHECK)
    }

    // Passo 2: olha a coluna direita
    private fun check() {
        if (!running) return
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                val found = bmp != null && hasPokemon(bmp)
                if (!running) return
                if (found) catchSequence() else tick()
            }
            override fun onFailure(errorCode: Int) {
                if (running) tick()
            }
        })
    }

    // Um pixel "aceso" = claro e não azulado (ignora cubos/pokéstops azuis)
    private fun lit(bmp: Bitmap, x: Int, y: Int): Boolean {
        if (x < 0 || y < 0 || x >= bmp.width || y >= bmp.height) return false
        val p = bmp.getPixel(x, y)
        val r = Color.red(p); val g = Color.green(p); val b = Color.blue(p)
        val bright = r > 140 || g > 140 || b > 140
        val bluish = b > r + 35 && b >= g
        return bright && !bluish
    }

    // Só conta áreas "grossas" (sprites). Círculos/linhas finas do mapa são ignorados.
    private fun hasPokemon(bmp: Bitmap): Boolean {
        val x0 = (bmp.width * DETECT.left).toInt()
        val x1 = (bmp.width * DETECT.right).toInt()
        val y0 = (bmp.height * DETECT.top).toInt()
        val y1 = (bmp.height * DETECT.bottom).toInt()
        val d = 7
        var count = 0
        for (y in y0 until y1 step 2) {
            for (x in x0 until x1 step 2) {
                if (lit(bmp, x, y) && lit(bmp, x - d, y) && lit(bmp, x + d, y) &&
                    lit(bmp, x, y - d) && lit(bmp, x, y + d)) count++
            }
        }
        return count > DETECT_MIN_PIXELS
    }

    // Passo 3: captura
    private fun catchSequence() {
        tap(RIGHT_FIRST)
        handler.postDelayed({
            if (!running) return@postDelayed
            tap(PLAYER)
            handler.postDelayed({
                if (!running) return@postDelayed
                swipe(THROW_FROM, THROW_TO)
                handler.postDelayed({ finish() }, WAIT_AFTER_THROW)
            }, WAIT_AFTER_TAP_PLAYER)
        }, WAIT_AFTER_TAP_RIGHT)
    }

    private fun finish() {
        stopBot()
        showBanner("Pokémon capturado com sucesso")
    }

    private fun showBanner(text: String) {
        removeBanner()
        val t = TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(230, 20, 100, 20))
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(48, 36, 48, 36)
            setOnClickListener { removeBanner() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(t, lp)
        banner = t
    }

    private fun removeBanner() {
        banner?.let { runCatching { wm.removeView(it) } }
        banner = null
    }

    private fun screenW() = wm.currentWindowMetrics.bounds.width()
    private fun screenH() = wm.currentWindowMetrics.bounds.height()

    private fun tap(p: PointF) {
        val path = Path().apply { moveTo(p.x * screenW(), p.y * screenH()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(g, null, null)
    }

    private fun swipe(a: PointF, b: PointF) {
        val path = Path().apply {
            moveTo(a.x * screenW(), a.y * screenH())
            lineTo(b.x * screenW(), b.y * screenH())
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build()
        dispatchGesture(g, null, null)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        removeBanner()
        panel?.let { runCatching { wm.removeView(it) } }
        instance = null
        super.onDestroy()
    }
}
